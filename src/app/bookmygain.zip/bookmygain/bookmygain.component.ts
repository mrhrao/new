import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookmygain',
  templateUrl: './bookmygain.component.html',
  styleUrls: ['./bookmygain.component.css']
})
export class Bookmygain implements OnInit {


  constructor(){

  }

  ngOnInit() {
 } 

}

